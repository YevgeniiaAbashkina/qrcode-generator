<?php 
/**
 * Klebelayout: 
 * header: bauteil *, etage *, strang * 
 * body:   QR-code
 * footer: www.pkt-systeme.de 
 **/

?>


<?php 
    if ( ! isset( $_GET['start'] ) ) {
        echo '<h1>QR-Code generieren:</h1>';
        echo '<a class="button" href="?start">go</a>';
        
        return;
    }

    ini_set('max_execution_time', 300);
    require_once( './phpqrcode/qrlib.php' );
    

    $file_content = file_get_contents( __DIR__ . '/../input/11_12_x2.csv' );
    
    $rowcontent = explode( "\r", $file_content );

    $header = explode( ";", array_shift( $rowcontent ) );
    $data   = [];

    foreach ( $rowcontent as $nr => $str ) {
        $parts  = explode( ";", $str );
        $row_data = [];

        for( $i = 0; $i < count( $header ); $i++ ) 
            $row_data[ $header[ $i ] ] = $parts[ $i ];
            
        $data[] = $row_data;
    }

    $files = [];
    $tempDir = 'qrcodes/'; 

    $session_id = uniqid();

    foreach ( $data as $id => $item ) {

        /**
         * @var $pkt
         * @var $bauteil *
         * @var $projekt
         * @var $arc
         * @var $etage *
         * @var $strang *
         * @var $typ
         */
        
        extract( $item );

        $fileName = 'qr-code-' . $strang . '_' . $session_id . '-' . $id . '.png';
        
        $pngAbsoluteFilePath = $tempDir.$fileName;
        $urlRelativeFilePath = $tempDir.$fileName;

        $qr_content = implode( ', ', $item );

        if ( ! file_exists( $pngAbsoluteFilePath ) ) 
            $image = QRcode::png( $qr_content, $pngAbsoluteFilePath, QR_ECLEVEL_L, 15, 2 );

        $files[] = [ $bauteil . ', ' . $etage . ', ' . $strang, $urlRelativeFilePath ];

    }

    $rows = array_chunk( $files, 6 );

    ob_start();
?>

<?php if( ! empty( $data ) ) : ?>

    <html xml:lang="de" xmlns="http://www.w3.org/1999/xhtml" lang="de">
        <head>
            <meta http-equiv="content-type" content="text/html; charset=UTF-8">
            <style>
                html {
                    margin: 0; 
                    padding: 0;
                }

                body { 
                    margin: 5mm; 
                    padding: 0;
                    box-sizing: border-box;
                    font-family: 'Berthold-akzidenz-grotesk-be-super', Helvetica, sans-serif;
                }
                
                table {
                    width: 100%;
                    border-collapse: collapse;  
                }
                
                tr th,
                tr td {
                    text-align: center;
                }

                .tab-header th {
                    width: 16.66%;
                    height: .75cm;
                    vertical-align: bottom;
                    font-size: 14px;
                    font-weight: bold;
                }

                .tab-footer td {
                    font-size: 11px;
                    height: .7cm;
                    vertical-align: top;
                    font-weight: bold;
                }

                .page_break { 
                    page-break-before: always; 
                }
            </style>
        </head>

        <body>
            <?php  
                $row_count = 1;
            ?>

            <?php foreach( $rows as $row ) : ?>
                <?php 
                    $count = count( $row );
                    $append = 6 - $count;
                    
                    for( $i = $append; $i > 0; $i-- )
                        $row[] = [ '', '' ];

                ?>
                <table>
                    <?php 
                        echo '<tr class="tab-header">';
                            foreach ( $row as $item ) {

                                echo '<th>' . $item[0] . '</th>';
                            }
                        echo '</tr>';

                        echo '<tr class="tab-body">';
                            foreach ( $row as $item ) {
                                echo '<td><img src="' . $item[1] . '" width="115" height="115" /></td>';
                            }
                            
                        echo '</tr>';

                        echo '<tr class="tab-footer">';
                            foreach ( $row as $item ) {
                                echo '<td>www.pkt-systeme.de</td>';
                            }
                        echo '</tr>';
                    ?>
                </table>
                <?php if ( $row_count == 6 ) : ?>
                    <div class="page_break"></div>
                <?php endif; ?>
                <?php 
                    $row_count++;
                    if ( $row_count == 7 )
                            $row_count = 1;
                ?>
            <?php endforeach; ?>
        </body> 
    </html>
<?php endif; ?>

<?php
    $output = ob_get_clean();

    //echo $output;
    //die();

    require_once( './dompdf/autoload.inc.php' );

    use Dompdf\Dompdf;

    $dompdf = new Dompdf( array( 'enable_remote' => true ) );
    $dompdf->set_option( 'Berthold-akzidenz-grotesk-be-super', 'defaultFont' );
    $dompdf->set_option( 'isFontSubsettingEnabled', true );
    $dompdf->set_option('defaultMediaType', 'all');
    $dompdf->get_option( '' );
    $dompdf->loadHtml( $output );
    $dompdf->setPaper('A4');
    $dompdf->render();

    $pdf = $dompdf->output();
    file_put_contents( '11_12_x2.pdf', $pdf );
    //or
    //file_put_contents( '11_04_x2.pdf', $pdf );