<?php 
/**
 *  BEGIN:VCARD
 *  VERSION:3.0
 *
 *  N: Name + null //(FN: not work )
 *  ORG:           Company
 *  TITLE:         Dipl.-Ing. (FH) Leiter Produktion 
 *  TEL;WORK:      +1234567890
 *  TEL;TYPE=fax:  +1234567890
 *  TEL;TYPE=cell: +1234567890
 *  EMAIL:         example@domain.com
 *  WEB:           wwx.example.de
 *
 *  END:VCARD
 **/
?>

<?php 
    if ( ! isset( $_GET[ 'start' ] ) ) {
        echo '<h1>QR-Code generieren:</h1>';
        echo '<a class="button" href="?start">go</a>';
        
        return;
    }

    ini_set( 'max_execution_time', 300 );
    require_once( './phpqrcode/qrlib.php' );

    $file_content = file_get_contents( __DIR__ . '/../input/vc_25_07.csv' );
    $file_content = preg_replace('/^\xEF\xBB\xBF/', '', $file_content);

    $data = explode( "\r\n", $file_content );

    function parseContactsWithHeaders( $data ) {
        $headers = explode( ';', array_shift( $data ) );
        $headers = array_map( 'trim', $headers );

        $parsed = [];

        foreach ( $data as $contact ) {
            $parts = explode( ';' , $contact );
            $parts = array_map( 'trim' , $parts );

            $contactArray = [];

            foreach ( $headers as $index => $header ) {
                $contactArray[ $header ] = isset( $parts [ $index ] )  && ! empty( $parts[ $index ] ) && $parts[ $index ] ? $parts[$index] : null;
            }

            $parsed[] = $contactArray;
        }

        return $parsed;
    }

$parsedContacts = parseContactsWithHeaders( $data );

function createVCard( $contact ) {
    $vCard = "BEGIN:VCARD\n";
    $vCard .= "VERSION:3.0\n";

    if ( ! empty( $contact[ 'Name' ] ) ) {
        $vCard .= "N:" . null . ';' . $contact[ 'Name' ] . "\n";
    }

    if ( ! empty( $contact[ 'Firma' ] ) ) {
        $vCard .= "ORG:" . $contact[ 'Firma' ] . "\n";
    }

    if ( ! empty( $contact[ 'Position' ] ) ) {
        $vCard .= "TITLE:" . $contact[ 'Position' ] . "\n";
    }

    if ( ! empty( $contact[ 'Telefon' ] ) ) {
        $vCard .= "TEL;TYPE=work:" . $contact[ 'Telefon' ] . "\n";
    }
    
    if ( ! empty( $contact[ 'Fax' ] ) ) {
        $vCard .= "TEL;TYPE=fax:" . $contact['Fax'] . "\n";
    }
    
    if ( ! empty( $contact[ 'Mobil' ] ) ) {
        $vCard .= "TEL;TYPE=cell:" . $contact[ 'Mobil' ] . "\n";
    }

    if ( ! empty( $contact[ 'Straße' ] ) && $contact[ 'Ort' ] ) {
        $vCard .= "ADR:" . $contact[ 'Straße' ] . ";" . $contact[ 'Ort' ] . "\n";
    }

    if ( ! empty( $contact[ 'email' ] ) ) {
        $vCard .= "EMAIL:" . $contact[ 'email' ] . "\n";
    }

    if ( !empty( $contact[ 'Webseite' ] ) )
        $vCard .= "URL;TYPE=pref:https://" . $contact[ 'Webseite' ] . "\n";
    
    $vCard .= "END:VCARD\n";
    
    return $vCard;
}

foreach ( $parsedContacts as $index => $contact ) {

    $vCard = createVCard( $contact ); 
    $fileName = $index + 1 . '-' . 'contact_' .  $contact['Name'] . '.png';

    QRcode::png($vCard, $fileName, QR_ECLEVEL_L, 10); 
}