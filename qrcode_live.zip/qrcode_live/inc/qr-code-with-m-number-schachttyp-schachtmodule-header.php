<?php 
/**
 * Klebelayout: 
 * header: M-Nummer *, PKT Schachttyp * , Schachtmodule *
 * body:   QR-code
 * footer: www.pkt-systeme.de 
 **/
?>


<?php 
    if ( ! isset( $_GET['start'] ) ) {
        echo '<h1>QR-Code generieren:</h1>';
        echo '<a class="button" href="?start">go</a>';
        
        return;
    }

    ini_set('max_execution_time', 300);
    require_once( './phpqrcode/qrlib.php' );
    

    $file_content = file_get_contents( __DIR__ . '/../input/03_09_x1.csv' );
    //or
    //$file_content = file_get_contents( __DIR__ . '/../input/27_01_x2.csv' );
    
    $file_content = str_replace( [';;;;',';'], ['',', '], $file_content );
    $rowcontent = explode( "\r", $file_content );
    
    $data = [];

    foreach ( $rowcontent as $nr => $str ) {
        $data[] = $str;
    }

    $files = [];
    $tempDir = 'qrcodes/'; 

    foreach ( $data as $item ) {
        $codeContents = $item;
        $parts = explode( ",", $item ); 

        $m_number = trim( $parts[ 3 ] );
        $schachttype = trim( $parts[ 4 ] ); 
        $schachtmod = trim( $parts[ 5 ] ); 
        $fileName = 'qr-code-' . $schachtmod . '-' . uniqid() . '.png';
        
        $pngAbsoluteFilePath = $tempDir.$fileName;
        $urlRelativeFilePath = $tempDir.$fileName;

        if ( ! file_exists( $pngAbsoluteFilePath ) ) 
            $image = QRcode::png( $item, $pngAbsoluteFilePath, QR_ECLEVEL_L, 10, 0 );

        $files[] = [ $m_number . ', &nbsp; &nbsp; &nbsp; &nbsp; ' . $schachttype . ', ' . $schachtmod,  $urlRelativeFilePath ];
    }

    $rows = array_chunk( $files, 6 );

    ob_start();
?>

<?php if( ! empty( $data ) ) : ?>

    <html xml:lang="de" xmlns="http://www.w3.org/1999/xhtml" lang="de">
        <head>
            <meta http-equiv="content-type" content="text/html; charset=UTF-8">
            <style>
                html {
                    margin: 0; 
                    padding: 0;
                }

                body { 
                    margin: 5mm; 
                    padding: 0;
                    box-sizing: border-box;
                    font-family: 'Berthold-akzidenz-grotesk-be-super', Helvetica, sans-serif;
                }
                
                table {
                    width: 100%;
                    border-collapse: collapse;  
                }

                tr th {
                    text-align: start;
                }

                tr td {
                    text-align: center;
                }

                .tab-header {
                    height: 1.5cm;
                }

                .tab-header th {
                    width: 16%;
                    height: .75cm;
                    vertical-align: bottom;
                    font-size: 15px;
                    font-weight: bold;
                    padding-left: .3cm;
                }

                .tab-footer td {
                    font-size: 11px;
                    height: .7cm;
                    vertical-align: top;
                    font-weight: bold;
                }

                .page_break { 
                    page-break-before: always; 
                }
            </style>
        </head>

        <body>
            <?php  
                $row_count = 1;
            ?>

            <?php foreach( $rows as $row ) : ?>
                <?php 
                    $count = count( $row );
                    $append = 6 - $count;
                    
                    for( $i = $append; $i > 0; $i-- )
                        $row[] = [ '', '' ];

                ?>
                <table>
                    <?php 
                        echo '<tr class="tab-header">';
                            foreach ( $row as $item ) {

                                echo '<th>' . $item[0] . '</th>';
                            }
                        echo '</tr>';

                        echo '<tr class="tab-body">';
                            foreach ( $row as $item ) {
                                echo '<td><img src="' . $item[1] . '" width="108" height="108" /></td>';
                            }
                            
                        echo '</tr>';

                        echo '<tr class="tab-footer">';
                            foreach ( $row as $item ) {
                                echo '<td>www.pkt-systeme.de</td>';
                            }
                        echo '</tr>';
                    ?>
                </table>
                <?php if ( $row_count == 6 ) : ?>
                    <div class="page_break"></div>
                <?php endif; ?>
                <?php 
                    $row_count++;
                    if ( $row_count == 7 )
                            $row_count = 1;
                ?>
            <?php endforeach; ?>
        </body> 
    </html>
<?php endif; ?>

<?php
    $output = ob_get_clean();

    //echo $output;
    //die();

    require_once( './dompdf/autoload.inc.php' );

    use Dompdf\Dompdf;

    $dompdf = new Dompdf( array( 'enable_remote' => true ) );
    $dompdf->set_option( 'Berthold-akzidenz-grotesk-be-super', 'defaultFont' );
    $dompdf->set_option( 'isFontSubsettingEnabled', true );
    $dompdf->set_option('defaultMediaType', 'all');
    $dompdf->get_option( '' );
    $dompdf->loadHtml( $output );
    $dompdf->setPaper('A4');
    $dompdf->render();

    $pdf = $dompdf->output();
    file_put_contents( '03_09_x2.pdf', $pdf );
    //or
    //file_put_contents( '27_01_x2.pdf', $pdf );