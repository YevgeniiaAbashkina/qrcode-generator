<?php 
    ini_set( 'max_execution_time', 300 );
    require_once( './phpqrcode/qrlib.php' );
    require_once( './vendor/autoload.php' );

    use Dompdf\Dompdf;

    // ===== INPUT =====
    $headerFields   = explode( ',', $_POST['header_fields'] );
    $headerFontSize = ! empty( $_POST['header_font_size'] ) ? $_POST['header_font_size'] : '12';
    $qrSize         = ! empty( $_POST['qr_size'] ) ? $_POST['qr_size'] : '100';
    $footer         = ! empty( $_POST['footer'] ) ? $_POST['footer'] : '';


    // ===== CSV UPLOAD =====
    $tmpName = $_FILES['csv_file']['tmp_name'];
    $file_content = file_get_contents( $tmpName );
    
    $rowcontent = explode( "\r", $file_content );
    $header = explode( ";", array_shift( $rowcontent ) );
    $data   = [];

    if ( ( $file = fopen( $tmpName, 'r' ) ) !== false ) {
        $header = fgetcsv( $file, 0, ";" );

        if ( ! $header ) 
            die( "CSV Header fehlt" );
        
        while ( ( $row = fgetcsv( $file, 0, ";" ) ) !== false) {
            if ( empty( array_filter( $row ) ) ) 
                continue;

            if ( count( $header ) !== count( $row ) ) 
                continue;

            $data[] = array_combine( $header, $row );
        }

        fclose( $file );
    }

    // ===== QR GENERATION =====
    $session_id = uniqid();
    $tempDir = sys_get_temp_dir() . '/qr_' . $session_id . '/';

    if ( ! is_dir( $tempDir ) ) {
        mkdir( $tempDir, 0777, true );
    } 

    $files = [];

    foreach ( $data as $id => $item ) {
        extract( $item );

        $fileName = "qr-$session_id-$id.png";
        $path = $tempDir . $fileName;

        $qr_content = implode( ', ', $item );
        QRcode::png( $qr_content, $path, QR_ECLEVEL_L, 10, 2 );

        $headerText = [];

        foreach ( $headerFields as $field ) {
            $field = trim( $field );
            $headerText[] = $item[ $field ] ?? '';
        }

        $files[] = [ implode(', ', $headerText ), $path ];
    }

    $rows = array_chunk( $files, 6 );

    ob_start();
?>

<?php if( ! empty( $data ) ) : ?>

    <html xml:lang="de" xmlns="http://www.w3.org/1999/xhtml" lang="de">
        <head>
            <meta http-equiv="content-type" content="text/html; charset=UTF-8">
            <style>
                html {
                    margin: 0; 
                    padding: 0;
                }

                body { 
                    margin: 5mm; 
                    padding: 0;
                    box-sizing: border-box;
                    font-family: 'Berthold-akzidenz-grotesk-be-super', Helvetica, sans-serif;
                }
                
                table {
                    width: 100%;
                    border-collapse: collapse;  
                }
                
                tr th,
                tr td {
                    text-align: center;
                }

                .tab-header th {
                    width: 16.66%;
                    height: .75cm;
                    vertical-align: bottom;
                    font-weight: bold;
                    font-size: <?php echo intval( $headerFontSize ) ?>px;
                }

                .tab-footer td {
                    font-size: 11px;
                    height: .7cm;
                    vertical-align: top;
                    font-weight: bold;
                }

                .page_break { 
                    page-break-before: always; 
                }
            </style>
        </head>

        <body>
            <?php  
                $row_count = 1;
            ?>

            <?php foreach( $rows as $row ) : ?>
                <?php 
                    $count = count( $row );
                    $append = 6 - $count;
                    
                    for( $i = $append; $i > 0; $i-- )
                        $row[] = [ '', '' ];

                ?>
                <table>
                    <?php 
                        echo '<tr class="tab-header">';
                            foreach ( $row as $item ) 
                                echo '<th>' . $item[0] . '</th>';
                            
                        echo '</tr>';

                        echo '<tr class="tab-body">';
                            foreach ( $row as $item ) {
                                $img = '';
                                if ( ! empty( $item[1] ) && file_exists( $item[1] ) ) 
                                    $img = 'data:image/png;base64,' . base64_encode( file_get_contents( $item[1] ) );
                                
                                
                                echo '<td><img src="' . $img . '" width="' .  $qrSize . '" height="' . $qrSize . '" /></td>';
                            }
                            
                        echo '</tr>';

                        echo '<tr class="tab-footer">';
                            foreach ( $row as $item ) 
                                echo '<td>' . $footer .'</td>';
                            
                        echo '</tr>';
                    ?>
                </table>
                <?php if ( $row_count == 6 ) : ?>
                    <div class="page_break"></div>
                <?php endif; ?>
                <?php 
                    $row_count++;
                    if ( $row_count == 7 )
                        $row_count = 1;
                ?>
            <?php endforeach; ?>
        </body> 
    </html>
<?php endif; ?>

<?php
    $output = ob_get_clean();

    //echo $output;
    //die();

    // ===== PDF =====

    $dompdf = new Dompdf();

    $options = $dompdf->getOptions();
    $options->set( 'enable_remote', true );
    $options->set( 'isHtml5ParserEnabled', true );
    $options->set( 'isFontSubsettingEnabled', true );
    $options->set( 'defaultMediaType', 'all' );

    $dompdf->setOptions( $options );

    $dompdf->loadHtml( $output );
    $dompdf->setPaper( 'A4' );
    $dompdf->setBasePath( __DIR__ );
    $dompdf->render();

    $dompdf->stream( "qrcodes.pdf", ["Attachment" => false] );

    exit;