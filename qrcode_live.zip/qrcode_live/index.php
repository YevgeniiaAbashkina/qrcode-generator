<?php 
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
        require 'generate.php';
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style/style.css" rel="stylesheet" type="text/css" />

    <title>P191 QR-Code Generator</title>
</head>

<body>
    <div class="wrapper body-wrapper">
        <header>
            <h1 class="title">QR-Code Generator</h1>
            <div class="image">
                <img src="image/qr.svg" alt="muster">
            </div>
            <p><b>Muster:</b> PKT, Haus A, HH0608, -, GB, S6, Schacht A1, Typ-D</p>
        </header>
        
        <div class="dropdown">
            <h2 class="title dropdown">Hinweise zur Verwendung des QR-Code-Generators</h2>
            <input class="hidden flag" id="dropdown-flag" type="checkbox">
            <label class="trigger" for="dropdown-flag"><img src="image/caret-down.png" alt="dropdown-button"></label>

            <div class="dropdown-content">
                <p class="dropdown-note">
                    Dieser QR-Code-Generator erstellt zunächst eine Zwischenstufe als PDF-Datei.
                </p>

                <ol class="dropdown-list">
                    <li>
                        <span class="list-title">Excel-Datei vorbereiten</span>
                        Sie erhalten eine Excel-Tabelle mit allen Daten und Mustern.
                    </li>
                
                    <li>
                        <span class="list-title">Daten sortieren</span>
                        Achten Sie darauf, dass einige Einträge unterschiedliche Anzahlen enthalten. Sortieren Sie daher zunächst alle Zeilen in Excel:
                        <ul>
                            <li>Markieren Sie die relevanten Daten</li>
                            <li><b>Hinweis:</b> Wenn Ihr Dokument nur die Anzahl „1“ enthält, können Sie nähsten 2 Schritte überspringen.</li>
                            <li>Gehen Sie zu „Sortieren und Filtern“ → „Benutzerdefiniertes Sortieren“</li>
                            <li>Wählen Sie die Spalte mit der Anzahl bei „Sortieren nach“</li>
                        </ul>
                    </li>

                    <li>
                        <span class="list-title">Daten nach Anzahl aufteilen</span>
                        <ul>
                            <li>Kopieren Sie alle Zeilen mit der gleichen Anzahl (ohne Muster und Kopfzeile)</li>
                            <li>Öffnen Sie eine neue Excel-Datei und fügen Sie die Daten dort ein</li>
                            <li>Die Spalte „Anzahl“ kann anschließend gelöscht werden</li>
                        </ul>
                    </li>

                    <li>
                        <span class="list-title">Spaltenüberschriften hinzufügen</span>
                        Fügen Sie im neuen Dokument wieder die entsprechenden Spaltennamen (Header) hinzu.
                    </li>

                    <li>
                        <span class="list-title">Datei speichern</span>
                        <ul>
                            <li>Klicken Sie auf „Speichern unter“</li>
                            <li>Geben Sie der Datei einen passenden Namen (idealerweise mit Angabe der Anzahl)</li>
                            <li>Wählen Sie als Dateityp: <b>„CSV UTF-8 (durch Trennzeichen getrennt (*.csv))“</b></li>
                        </ul>
                    </li>
                </ol>
                <hr>

                <p class="dropdown-note">Nach diesen Schritten sind Ihre Daten korrekt vorbereitet und Sie können den QR-Code-Generator problemlos verwenden.<b>Viel Erfolg!</b></p>
            </div>


        </div>

        <form class="form" method="post" enctype="multipart/form-data">

            <div class="form-wrapper">
                <label>CSV Datei:</label></br>
                <input type="file" name="csv_file" required></br></br>
    
                <label>Header Felder* (CSV Spaltennamen):</label></br>
                <input type="text" name="header_fields" value="" placeholder="haus,etage,typ" require></br></br>
    
                <label>Header font-size (in px):</label><br>
                <input type="text" name="header_font_size" value="" placeholder="default: 12px"><br><br>
    
                <label>QR size:</label><br>
                <input name="qr_size" value="" placeholder="default: 100px"><br><br>
    
                <label>Footer:</label><br>
                <input type="text" name="footer" value="" placeholder="default: leer"><br><br>
    
                <button class="button" type="submit">PDF generieren</button>
            </div>

    </form>
</div>
<footer class="footer">
    <p class="wrapper">Entwickelt bei Page Pro Media GmbH | 2026</p>
</footer>
</body>
</html>