<?php 
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style/style.css" rel="stylesheet" type="text/css" />

    <title>P191 QR-Code Generator</title>
</head>

<body>
    <div class="wrapper">

        
        <?php 
            //require_once( 'inc/data-from-excel-convertation.php' );

            /**
             * type: vCards;
             *
             * generate vCards
             * output: .png files 100*100px
             */
            
            //require_once( 'inc/qr-code-vcard.php' );

            /**
             * type: qr-codes;
             *
             * generate qr-codes
             * output: .pdf 6*6 pro page
             */

            //require_once( 'inc/qr-code-with-bauteil-etage-strang-header.php' ); 
            //require_once( 'inc/qr-code-with-house-etage-type-schacht-header.php' );
            require_once( 'inc/qr-code-with-etage-type-schacht-header.php' );
        ?>
    </div>
</body>
</html>