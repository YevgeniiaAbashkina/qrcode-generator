<?php 
    ini_set('max_execution_time', 300);

    require_once( './phpqrcode/qrlib.php' );

    echo '<h1>QR-Code generieren:</h1>';

    echo '<a class="button" href="?start">go</a>';

    if ( ! isset( $_GET['start'] ) )
    return;

    ob_start();

    $file_content = file_get_contents( __DIR__ . '/../input/data.csv' );

    $file_content = str_replace( [';;;;',';'], ['',', '], $file_content );
    $rowcontent = explode( "\r", $file_content );
    
    $data = [];

    foreach ( $rowcontent as $nr => $str ) {
        $data[] = $str;
    }

    $rows = array_chunk( $data, 6 );

    $tempDir = 'qrcodes/'; ?>

<?php if( ! empty( $data ) ) : ?>

    <html xml:lang="de" xmlns="http://www.w3.org/1999/xhtml" lang="de">
        <head>
            <meta http-equiv="content-type" content="text/html; charset=UTF-8">
            <style>
                body { 
                    margin: 0; 
                    margin-top: 2.3rem;
                    padding: 0;
                    box-sizing: border-box;
                    font-family: 'Berthold-akzidenz-grotesk-be-super', Helvetica, sans-serif;
                }
                
                table {
                    margin: auto;
                    border-collapse: collapse;  
                }
                
                tr th,
                tr td {
                    border: 1px solid red; 
                    text-align: center;
                }

                .tab-header th {
                    height: 28px;
                    vertical-align: bottom;
                    font-size: 18px;
                    font-weight: bold;
                    border-bottom: none;
                }

                .tab-body td {
                    border-top: none;
                    border-bottom: none;
                }

                .tab-footer td {
                    border-top: none;
                    border-bottom: 1px solid red;
                    font-size: 10px;
                    height: 16px;
                    vertical-align: top;
                }
            </style>
        </head>

        <body>
            <?php foreach( $rows as $row ) : ?>   
                <table>
                    <?php 
                        echo '<tr class="tab-header">';
                            foreach ( $row as $key => $item ) {
                                $parts = explode( ",", $item ); 
                                $haus_num = trim( $parts[ 1 ] ); 

                                echo '<th>' . $haus_num . '</th>';
                            }
                        echo '</tr>';

                        echo '<tr class="tab-body">';
                            foreach ( $row as $key => $item ) {
                                $codeContents = $item;

                                $parts = explode( ",", $item ); 
                                $haus_num = trim( $parts[ 1 ] ); 
                                $fileName = 'qr-code-' . $haus_num . '-' . uniqid() . '.png';
                                
                                $pngAbsoluteFilePath = $tempDir.$fileName;
                                $urlRelativeFilePath = $tempDir.$fileName;

                                if ( ! file_exists( $pngAbsoluteFilePath ) ) 
                                    $image = QRcode::png( $item, $pngAbsoluteFilePath, QR_ECLEVEL_L, 15, 3);

                                echo '<td><img src="' . $urlRelativeFilePath . '" width="110" height="110" /></td>';
                            }
                            
                        echo '</tr>';

                        echo '<tr class="tab-footer">';
                            foreach ( $row as $key => $item ) {
                                echo '<td>www.pkt-systeme.de</td>';
                            }
                        echo '</tr>';
                    ?>
                </table>
            <?php endforeach; ?>
        </body> 
    </html>
<?php endif; ?>

<?php
    $output = ob_get_clean();

    require_once( './dompdf/autoload.inc.php' );

    use Dompdf\Dompdf;

    $dompdf = new Dompdf( array( 'enable_remote' => true ) );
    $dompdf->set_option('Berthold-akzidenz-grotesk-be-super', 'defaultFont');
    $dompdf->set_option('isFontSubsettingEnabled', true);
    $dompdf->set_option('defaultMediaType', 'all');
    $dompdf->get_option('');
    $dompdf->loadHtml( $output );
    $dompdf->setPaper('A4');
    $dompdf->render();

    $pdf = $dompdf->output();
    file_put_contents( 'test.pdf', $pdf );