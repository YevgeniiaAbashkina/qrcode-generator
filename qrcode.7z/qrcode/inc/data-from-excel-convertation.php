<h1>PHP-Programm erstellen zum Excel-Daten auslesen</h1>
<ol>
    <li>Du sollst jetzt alle Spalten in deine Excel-Tabelle kopieren (Strg + C).</li>
    <li>Dann sollst du die zuvor kopierten Daten an der ausgewählten Stelle in diser Tabelle einfügen, indem du die Tastenkombination 'Strg + V' verwendest. Drücke 'Speichern'.</li>
</ol>

<form method="post">
    <textarea name="content" rows="30" cols="150" wrap="hard">

        <?php
            if ( isset( $_REQUEST[ 'content' ] ))
            {
                $rowcontent = explode( "\r", trim( $_REQUEST['content'] ) );

                foreach ($rowcontent AS $nr => $row) {
                    $data[$nr] = implode(", ", explode("\t", trim(str_replace(' - ', '-', $row))));
                }

                $data_string = "'" . implode("',\n'", $data) . "'";
                echo $data_string;
                exit;
            }
        ?>

    </textarea>
    <br/><br/>
    <input class="button" name="" type="submit" value="Speichern">
</form>